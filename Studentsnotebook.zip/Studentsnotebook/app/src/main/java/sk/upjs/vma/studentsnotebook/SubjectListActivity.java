package sk.upjs.vma.studentsnotebook;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class SubjectListActivity extends AppCompatActivity {

    private SubjectDao subjectDao = SubjectDao.INSTANCE;

    private ListView listView;

    public static final String SUBJECT_ID_EXTRA = "subjectId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subject_list);

        listView = findViewById(R.id.listViewSubjects);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Log.d(SubjectListActivity.class.getName(), "on item click " + position);

                Intent intent = new Intent(SubjectListActivity.this,
                        SubjectDetailActivity.class);

                Subject subject = subjectDao.list().get(position);

                intent.putExtra(SUBJECT_ID_EXTRA, subject.getId());
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        List<Subject> list = subjectDao.list();

        ListAdapter adapter = new ArrayAdapter<Subject>(this,
                android.R.layout.simple_list_item_1, list) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView listItemView = (TextView) super.getView(position, convertView, parent);

                Subject subject = getItem(position);

                listItemView.setText(subject.getName());
                return listItemView;
            }
        };

        // adapter sa nastavuje v onResume, aby sa zoznam aktualizoval pri navrate z DetailActivity
        listView.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.subject_list_action_bar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.addNewSubject) {
            Log.d("Hello", "vytvorenie novej aktivity");

            /*Uri uri = Uri.parse("https://www.upjs.sk/");
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);*/

            Intent intent = new Intent(this, SubjectDetailActivity.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }

}
